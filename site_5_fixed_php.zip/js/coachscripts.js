// سیستم چت و خرید مربیگری
document.addEventListener('DOMContentLoaded', function() {
  // متغیرهای چت
  let chatSocket;
  let currentUserId = null;
  let currentUserName = 'کاربر';
  let isAdmin = false;
  
  // سیستم چت
  initLiveChat();
  
  // سیستم رزرو جلسات
  initBookingSystem();
  
  // تابع مقداردهی اولیه چت
  function initLiveChat() {
    const chatToggle = document.getElementById('liveChatToggle');
    const chatModal = document.getElementById('chatModal');
    const closeChat = document.querySelector('.close-chat');
    const sendButton = document.getElementById('sendMessage');
    const chatInput = document.getElementById('chatInput');
    
    chatToggle.addEventListener('click', () => {
        chatModal.style.display = chatModal.style.display === 'block' ? 'none' : 'block';
    });
    
    closeChat.addEventListener('click', () => {
        chatModal.style.display = 'none';
    });
    
    sendButton.addEventListener('click', sendMessage);
    chatInput.addEventListener('keypress', (e) => {
        if(e.key === 'Enter') sendMessage();
    });
    
    function sendMessage() {
        const message = chatInput.value.trim();
        if(!message) return;
        
        // Add user message
        addMessage(message, 'user');
        chatInput.value = '';
        
        // Auto response
        setTimeout(() => {
            const responses = [
                'برای رزرو جلسه مربیگری می‌توانید از بخش رزرو جلسه در صفحه اقدام کنید.',
                'چه پوزیشنی را برای مربیگری نیاز دارید؟ می‌توانم راهنمایی کنم.',
                'مربیان ما در کمتر از 24 ساعت با شما تماس خواهند گرفت.',
                'آیا سوال خاصی درباره روند مربیگری دارید؟',
                'برای انتخاب مربی مناسب می‌توانید از بخش مربیان ما دیدن کنید.'
            ];
            const randomResponse = responses[Math.floor(Math.random() * responses.length)];
            addMessage(randomResponse, 'admin');
        }, 1000);
    }
    
    function addMessage(text, sender) {
        const messageElement = document.createElement('div');
        messageElement.className = `${sender}-message`;
        
        const time = new Date().toLocaleTimeString('fa-IR', {
            hour: '2-digit',
            minute: '2-digit'
        });
        
        messageElement.innerHTML = `
            <p>${text}</p>
            <span class="message-time">${time}</span>
        `;
        
        document.getElementById('chatMessages').appendChild(messageElement);
        scrollChatToBottom();
    }
    
    function scrollChatToBottom() {
        const chatMessages = document.getElementById('chatMessages');
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
  }

  // تابع مقداردهی اولیه سیستم رزرو
  function initBookingSystem() {
    // تغییر پوزیشن‌ها
    document.querySelectorAll('.option-btn[data-role]').forEach(btn => {
      btn.addEventListener('click', function() {
        document.querySelectorAll('.option-btn[data-role]').forEach(b => b.classList.remove('selected'));
        this.classList.add('selected');
        
        // نمایش دلایل مربوطه
        document.querySelectorAll('.role-reasons').forEach(el => el.style.display = 'none');
        document.getElementById(`${this.dataset.role}-reasons`).style.display = 'block';
      });
    });
    
    // تغییر نوع جلسه
    document.querySelectorAll('.option-btn[data-sessions]').forEach(btn => {
      btn.addEventListener('click', function() {
        document.querySelectorAll('.option-btn[data-sessions]').forEach(b => b.classList.remove('selected'));
        this.classList.add('selected');
        updatePrice();
      });
    });
    
    // جلسه آزمایشی
    document.getElementById('trial-option').addEventListener('click', function() {
      document.querySelectorAll('.option-btn[data-sessions]').forEach(b => b.classList.remove('selected'));
      this.classList.add('selected');
      updatePrice();
    });
    
    // انتخاب رنک
    document.querySelectorAll('.rank-option').forEach(option => {
      option.addEventListener('click', function() {
        document.querySelectorAll('.rank-option').forEach(o => o.classList.remove('selected'));
        this.classList.add('selected');
      });
    });
    
    // پرداخت
    document.getElementById('payment-link').addEventListener('click', function(e) {
      e.preventDefault();
      goToPayment();
    });
  }
  
  // تابع انتقال به صفحه پرداخت
  function goToPayment() {
    const selectedRole = document.querySelector('.option-btn[data-role].selected').dataset.role;
    const selectedPackage = document.querySelector('.option-btn[data-sessions].selected')?.dataset.sessions || 'trial';
    const rank = document.querySelector('.rank-option.selected')?.dataset.rank || 'unknown';
    const goals = document.getElementById('coaching-reasons').value;
    const contactInfo = document.getElementById('contact-info').value;
    const price = document.getElementById('total-price').textContent.replace('جمع کل: ', '');
    
    // ذخیره اطلاعات در localStorage
    localStorage.setItem('bookingDetails', JSON.stringify({
      role: selectedRole,
      package: selectedPackage,
      rank: rank,
      goals: goals,
      contact: contactInfo,
      price: price
    }));
    
    // انتقال به صفحه پرداخت
    window.location.href = 'payment.html';
  }

  // تابع بروزرسانی قیمت
  function updatePrice() {
    const basePrice = 180000;
    let finalPrice = basePrice;
    let discount = 0;
    
    // محاسبه تخفیف بر اساس تعداد جلسات
    const selectedPackage = document.querySelector('.option-btn[data-sessions].selected');
    if(selectedPackage) {
      const sessions = parseInt(selectedPackage.dataset.sessions);
      
      if(sessions === 3) discount = 0.1;
      else if(sessions === 5) discount = 0.15;
      else if(sessions === 10) discount = 0.2;
      
      finalPrice = basePrice * sessions * (1 - discount);
    } else {
      // جلسه آزمایشی
      finalPrice = 50000;
    }
    
    // نمایش قیمت
    document.getElementById('base-price').textContent = `${(finalPrice/1000).toFixed(0)}0,000 تومان`;
    document.getElementById('total-price').textContent = `جمع کل: ${(finalPrice/1000).toFixed(0)}0,000 تومان`;
  }

  // نمایش نوتیفیکیشن
  function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
      notification.classList.add('fade-out');
      setTimeout(() => {
        notification.remove();
      }, 500);
    }, 3000);
  }
});