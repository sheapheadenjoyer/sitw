
document.addEventListener("DOMContentLoaded", function () {
    loadTeamData();
    document.getElementById("createTeamForm")?.addEventListener("submit", createTeam);
    document.getElementById("inviteBtn")?.addEventListener("click", inviteToTeam);
    document.getElementById("leaveBtn")?.addEventListener("click", leaveTeam);
});

function loadTeamData() {
    fetch("backend/get_team_data.php")
        .then(res => res.json())
        .then(data => {
            const container = document.getElementById("teamContent");
            if (!data.in_team) {
                container.innerHTML = `
                    <form id="createTeamForm">
                        <input type="text" name="team_name" placeholder="نام تیم" required>
                        <input type="text" name="team_tag" placeholder="تگ تیم" required>
                        <button type="submit">ساخت تیم</button>
                    </form>
                `;
                document.getElementById("createTeamForm").addEventListener("submit", createTeam);
            } else {
                let members = data.members.map(m => `<li>${m.username} - ${m.role}</li>`).join("");
                let inviteInput = data.user_role === 'leader' ? `
                    <input type="number" id="inviteId" placeholder="ID کاربر برای دعوت">
                    <button id="inviteBtn">دعوت</button>
                ` : '';
                let leaveBtn = `<button id="leaveBtn">ترک تیم</button>`;
                container.innerHTML = `
                    <h3>${data.team_name} (${data.team_tag})</h3>
                    <ul>${members}</ul>
                    ${inviteInput}
                    ${leaveBtn}
                `;
                if (data.user_role === 'leader') {
                    document.getElementById("inviteBtn").addEventListener("click", inviteToTeam);
                }
                document.getElementById("leaveBtn").addEventListener("click", leaveTeam);
            }
        });
}

function createTeam(e) {
    e.preventDefault();
    const form = new FormData(e.target);
    fetch("backend/create_team.php", {
        method: "POST",
        body: form
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            alert("تیم ساخته شد!");
            loadTeamData();
        } else {
            alert("خطا: " + (data.error || "ایجاد تیم شکست خورد"));
        }
    });
}

function inviteToTeam() {
    const friendId = document.getElementById("inviteId").value;
    const form = new FormData();
    form.append("friend_id", friendId);
    fetch("backend/invite_to_team.php", {
        method: "POST",
        body: form
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            alert("دعوت انجام شد!");
            loadTeamData();
        } else {
            alert("خطا: " + (data.error || "دعوت ممکن نیست"));
        }
    });
}

function leaveTeam() {
    fetch("backend/leave_team.php", { method: "POST" })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                alert("از تیم خارج شدید.");
                loadTeamData();
            }
        });
}
