document.addEventListener('DOMContentLoaded', function () {
  initBookingSystem();

  function initBookingSystem() {
    // انتخاب پوزیشن‌ها
    document.querySelectorAll('.option-btn[data-role]').forEach(btn => {
      btn.addEventListener('click', function () {
        document.querySelectorAll('.option-btn[data-role]').forEach(b => b.classList.remove('selected'));
        this.classList.add('selected');

        // نمایش دلایل مربوط به پوزیشن
        document.querySelectorAll('.role-reasons').forEach(el => el.style.display = 'none');
        document.getElementById(`${this.dataset.role}-reasons`).style.display = 'block';
      });
    });

    // انتخاب پکیج‌های حرفه‌ای
    document.querySelectorAll('.option-btn[data-sessions]').forEach(btn => {
      btn.addEventListener('click', function () {
        document.querySelectorAll('.option-btn[data-sessions]').forEach(b => b.classList.remove('selected'));
        document.getElementById('trial-option')?.classList.remove('selected');
        this.classList.add('selected');
        updatePrice();
      });
    });

    // جلسه آزمایشی
    const trial = document.getElementById('trial-option');
    if (trial) {
      trial.addEventListener('click', function () {
        document.querySelectorAll('.option-btn[data-sessions]').forEach(b => b.classList.remove('selected'));
        this.classList.add('selected');
        updatePrice();
      });
    }

    // انتخاب رنک
    document.querySelectorAll('.rank-option').forEach(option => {
      option.addEventListener('click', function () {
        document.querySelectorAll('.rank-option').forEach(o => o.classList.remove('selected'));
        this.classList.add('selected');
      });
    });

    // کلیک روی پرداخت
    document.getElementById('payment-link')?.addEventListener('click', function (e) {
      e.preventDefault();
      goToPayment();
    });

    // محاسبه قیمت اولیه
    updatePrice();
  }

  function updatePrice() {
    const basePrice = 180000;
    let finalPrice = basePrice;
    let discount = 0;

    const selectedPackage = document.querySelector('.option-btn[data-sessions].selected');
    if (selectedPackage) {
      const sessions = parseInt(selectedPackage.dataset.sessions);

      if (sessions === 3) discount = 0.1;
      else if (sessions === 5) discount = 0.15;
      else if (sessions === 10) discount = 0.2;

      finalPrice = basePrice * sessions * (1 - discount);
    } else {
      finalPrice = 50000; // جلسه آزمایشی
    }

    document.getElementById('base-price').textContent = `${finalPrice.toLocaleString('fa-IR')} تومان`;
    document.getElementById('total-price').textContent = `جمع کل: ${finalPrice.toLocaleString('fa-IR')} تومان`;
  }

  function goToPayment() {
    const selectedRole = document.querySelector('.option-btn[data-role].selected')?.dataset.role || 'unknown';
    const selectedPackage = document.querySelector('.option-btn[data-sessions].selected')?.dataset.sessions || 'trial';
    const rank = document.querySelector('.rank-option.selected')?.dataset.rank || 'unknown';
    const goals = document.getElementById('coaching-reasons')?.value || '';
    const contactInfo = document.getElementById('contact-info')?.value || '';
    const price = document.getElementById('total-price')?.textContent?.replace('جمع کل: ', '') || '';

    if (!contactInfo.trim()) {
      alert('لطفاً راه ارتباطی (تلگرام یا شماره) را وارد کنید.');
      return;
    }

    localStorage.setItem('bookingDetails', JSON.stringify({
      role: selectedRole,
      package: selectedPackage,
      rank: rank,
      goals: goals,
      contact: contactInfo,
      price: price
    }));

    window.location.href = 'payment.html';
  }
});
