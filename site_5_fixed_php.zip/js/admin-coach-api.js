// admin-coach-api.js - مدیریت مربیگری در پنل ادمین

/**
 * ماژول مدیریت مربیگری در پنل ادمین
 */
const AdminCoachModule = (() => {
  // بارگیری جلسات مربیگری
  const loadCoachSessions = async () => {
    try {
      const response = await fetch('/admin/api/coaches/sessions');
      const data = await response.json();
      renderCoachSessions(data.sessions);
    } catch (error) {
      console.error('Error loading coach sessions:', error);
      showError('خطا در بارگیری جلسات مربیگری');
    }
  };

  // نمایش جلسات در جدول
  const renderCoachSessions = (sessions) => {
    const tableBody = document.getElementById('coaching-sessions-body');
    tableBody.innerHTML = '';
    
    sessions.forEach(session => {
      const row = document.createElement('tr');
      row.innerHTML = `
        <td>${session.id}</td>
        <td>${session.student}</td>
        <td>${session.coach || 'تعیین نشده'}</td>
        <td>${session.position}</td>
        <td>${session.date}</td>
        <td><span class="status-badge ${getStatusClass(session.status)}">${session.status}</span></td>
        <td>
          <button class="btn btn-sm btn-primary assign-coach" data-id="${session.id}">انتخاب مربی</button>
          <button class="btn btn-sm btn-info view-details" data-id="${session.id}">جزئیات</button>
        </td>
      `;
      tableBody.appendChild(row);
    });
    
    setupCoachButtons();
  };

  // تنظیم رویدادهای دکمه‌ها
  const setupCoachButtons = () => {
    // دکمه انتصاب مربی
    document.querySelectorAll('.assign-coach').forEach(btn => {
      btn.addEventListener('click', function() {
        const sessionId = this.dataset.id;
        showCoachAssignmentModal(sessionId);
      });
    });
    
    // دکمه مشاهده جزئیات
    document.querySelectorAll('.view-details').forEach(btn => {
      btn.addEventListener('click', function() {
        const sessionId = this.dataset.id;
        showSessionDetails(sessionId);
      });
    });
  };

  // نمایش مدال انتصاب مربی
  const showCoachAssignmentModal = (sessionId) => {
    // در اینجا می‌توانید لیست مربیان را از سرور دریافت کنید
    const coaches = [
      {id: 1, name: 'مربی یک', position: 'پوزیشن 1'},
      {id: 2, name: 'مربی دو', position: 'پوزیشن 2'},
      {id: 3, name: 'مربی سه', position: 'پوزیشن 3'}
    ];
    
    const modalContent = `
      <div class="modal-header">
        <h5>انتخاب مربی برای جلسه #${sessionId}</h5>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <label>مربیان موجود:</label>
          <select class="form-control" id="coach-select">
            ${coaches.map(coach => 
              `<option value="${coach.id}">${coach.name} (${coach.position})</option>`
            ).join('')}
          </select>
        </div>
        <div class="form-group">
          <label>زمان پیشنهادی:</label>
          <input type="datetime-local" class="form-control" id="session-time">
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" data-dismiss="modal">انصراف</button>
        <button class="btn btn-primary" id="confirm-assignment">تایید انتصاب</button>
      </div>
    `;
    
    showModal('انتخاب مربی', modalContent);
    
    // رویداد تایید انتصاب
    document.getElementById('confirm-assignment').addEventListener('click', async () => {
      const coachId = document.getElementById('coach-select').value;
      const sessionTime = document.getElementById('session-time').value;
      
      try {
        const response = await assignCoachToSession(sessionId, coachId, sessionTime);
        showSuccess('مربی با موفقیت انتصاب یافت');
        loadCoachSessions(); // بارگیری مجدد لیست
      } catch (error) {
        showError('خطا در انتصاب مربی');
      }
    });
  };

  // انتصاب مربی به جلسه
  const assignCoachToSession = async (sessionId, coachId, sessionTime) => {
    const response = await fetch('/admin/api/coaches/assign', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({sessionId, coachId, sessionTime})
    });
    
    return response.json();
  };

  // نمایش جزئیات جلسه
  const showSessionDetails = async (sessionId) => {
    try {
      const response = await fetch(`/admin/api/coaches/sessions/${sessionId}`);
      const session = await response.json();
      
      const detailsContent = `
        <div class="session-details">
          <div class="detail-row">
            <span class="detail-label">کارآموز:</span>
            <span class="detail-value">${session.student}</span>
          </div>
          <div class="detail-row">
            <span class="detail-label">پوزیشن:</span>
            <span class="detail-value">${session.position}</span>
          </div>
          <div class="detail-row">
            <span class="detail-label">رنک:</span>
            <span class="detail-value">${session.rank}</span>
          </div>
          <div class="detail-row">
            <span class="detail-label">تاریخ:</span>
            <span class="detail-value">${session.date}</span>
          </div>
          <div class="detail-row">
            <span class="detail-label">وضعیت:</span>
            <span class="detail-value ${getStatusClass(session.status)}">${session.status}</span>
          </div>
          <div class="detail-row">
            <span class="detail-label">اهداف:</span>
            <p class="detail-value">${session.goals}</p>
          </div>
          ${session.coach ? `
          <div class="detail-row">
            <span class="detail-label">مربی:</span>
            <span class="detail-value">${session.coach}</span>
          </div>
          ` : ''}
          ${session.feedback ? `
          <div class="detail-row">
            <span class="detail-label">بازخورد:</span>
            <p class="detail-value">${session.feedback}</p>
          </div>
          ` : ''}
        </div>
      `;
      
      showModal(`جزئیات جلسه #${sessionId}`, detailsContent);
    } catch (error) {
      showError('خطا در دریافت جزئیات جلسه');
    }
  };

  // تابع کمکی برای کلاس وضعیت
  const getStatusClass = (status) => {
    switch(status.toLowerCase()) {
      case 'تکمیل شده': return 'status-completed';
      case 'در حال انجام': return 'status-pending';
      case 'لغو شده': return 'status-rejected';
      default: return '';
    }
  };

  return {
    init: () => {
      loadCoachSessions();
      console.log('Admin Coach Module initialized');
    }
  };
})();

// مقداردهی اولیه هنگام بارگذاری صفحه
document.addEventListener('DOMContentLoaded', () => {
  AdminCoachModule.init();
});