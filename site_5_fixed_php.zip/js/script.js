const Dota2Rush = (function() {
  
  // تابع شمارش معکوس برای تورنمنت
  function initCountdown() {
    const countDownDate = new Date();
    countDownDate.setMonth(countDownDate.getMonth() + 1);
    countDownDate.setDate(1);
    countDownDate.setHours(0, 0, 0, 0);
    
    const timerInterval = setInterval(updateCountdown, 1000);
    
    function updateCountdown() {
      const now = new Date().getTime();
      const distance = countDownDate - now;
      
      const days = Math.floor(distance / (1000 * 60 * 60 * 24));
      const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
      const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
      const seconds = Math.floor((distance % (1000 * 60)) / 1000);
      
      document.getElementById("days").textContent = days.toString().padStart(2, '0');
      document.getElementById("hours").textContent = hours.toString().padStart(2, '0');
      document.getElementById("minutes").textContent = minutes.toString().padStart(2, '0');
      document.getElementById("seconds").textContent = seconds.toString().padStart(2, '0');
      
      if (distance < 0) {
        clearInterval(timerInterval);
        document.querySelector('.coming-soon').textContent = 'تورنمنت شروع شده است!';
      }
    }
    
    updateCountdown();
  }
  
  // تابع اسکرول نرم برای لینک‌های داخلی
  function initSmoothScrolling() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
      anchor.addEventListener('click', function(e) {
        if (this.getAttribute('href') === '#') return;
        
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
          target.scrollIntoView({
            behavior: 'smooth'
          });
        }
      });
    });
  }
  
  // تابع پشتیبانی آنلاین (نسخه پیشرفته‌تر)
  function initLiveChat() {
    const chatToggle = document.getElementById('liveChatToggle');
    const chatModal = document.getElementById('chatModal');
    const closeChat = document.querySelector('.close-chat');
    const tabButtons = document.querySelectorAll('.tab-button');
    const contactAdminBtn = document.querySelector('.contact-admin-btn');
    const sendMessageBtn = document.getElementById('sendMessageToAdmin');
    const backToFaqBtn = document.querySelector('.back-to-faq');
    
    // باز و بسته کردن مودال
    if (chatToggle && chatModal) {
      chatToggle.addEventListener('click', function() {
        chatModal.style.display = "block";
        document.body.style.overflow = "hidden";
      });
      
      closeChat.addEventListener('click', function() {
        chatModal.style.display = "none";
        document.body.style.overflow = "auto";
      });
      
      window.addEventListener('click', function(event) {
        if (event.target === chatModal) {
          chatModal.style.display = "none";
          document.body.style.overflow = "auto";
        }
      });
    }
    
    // تغییر تب‌ها
    if (tabButtons.length > 0) {
      tabButtons.forEach(button => {
        button.addEventListener('click', function(e) {
          const tabId = e.target.getAttribute('data-tab');
          
          // حذف کلاس active از همه تب‌ها
          tabButtons.forEach(btn => btn.classList.remove('active'));
          document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.remove('active');
          });
          
          // اضافه کردن کلاس active به تب انتخاب شده
          e.target.classList.add('active');
          const activeTab = document.getElementById(`${tabId}-tab`);
          if (activeTab) activeTab.classList.add('active');
        });
      });
    }
    
    // باز کردن تب تماس با ادمین
    if (contactAdminBtn) {
      contactAdminBtn.addEventListener('click', function() {
        const contactTab = document.querySelector('.tab-button[data-tab="contact"]');
        if (contactTab) contactTab.click();
      });
    }
    
    // ارسال پیام به ادمین
    if (sendMessageBtn) {
      sendMessageBtn.addEventListener('click', function() {
        const email = document.getElementById('userEmail');
        const message = document.getElementById('userMessage');
        
        if (!email || !message || !email.value || !message.value) {
          alert('لطفاً تمام فیلدها را پر کنید');
          return;
        }
        
        // شبیه‌سازی ارسال پیام به سرور
        setTimeout(function() {
          const adminResponse = document.getElementById('adminResponse');
          const contactTab = document.getElementById('contact-tab');
          
          if (adminResponse && contactTab) {
            contactTab.style.display = 'none';
            adminResponse.style.display = 'block';
            
            // ریست کردن فرم
            email.value = '';
            message.value = '';
            
            // ذخیره پیام در localStorage
            const messages = JSON.parse(localStorage.getItem('support-messages') || '[]');
            messages.push({
              email: email.value,
              message: message.value,
              date: new Date().toISOString()
            });
            localStorage.setItem('support-messages', JSON.stringify(messages));
          }
        }, 1000);
      });
    }
    
    // بازگشت به سوالات
    if (backToFaqBtn) {
      backToFaqBtn.addEventListener('click', function() {
        const faqTab = document.querySelector('.tab-button[data-tab="faq"]');
        if (faqTab) faqTab.click();
        const adminResponse = document.getElementById('adminResponse');
        if (adminResponse) adminResponse.style.display = 'none';
      });
    }
    
    // کلیک روی سوالات متداول
    document.querySelectorAll('.faq-question').forEach(question => {
      question.addEventListener('click', function(e) {
        const faqItem = e.target.closest('.faq-item');
        if (faqItem) faqItem.classList.toggle('active');
      });
    });
  }
  
  // تابع نمایش/مخفی کردن مقالات
  function initArticleToggles() {
    document.querySelectorAll('.read-article').forEach(link => {
      link.addEventListener('click', function(e) {
        e.preventDefault();
        const contentId = this.getAttribute('data-article') + '-content';
        const content = document.getElementById(contentId);
        if (content) {
          content.classList.toggle('show');
          this.textContent = content.classList.contains('show') ? 
            'بستن مقاله' : 'ادامه مطلب';
        }
      });
    });
  }
  
  // تابع مدیریت اسکرول صفحه
  function initScrollFunctions() {
    // دکمه بازگشت به بالا
    const backToTopButton = document.getElementById('backToTop');
    
    if (backToTopButton) {
      window.addEventListener('scroll', function() {
        backToTopButton.classList.toggle('visible', window.scrollY > 300);
      });
      
      backToTopButton.addEventListener('click', function() {
        window.scrollTo({
          top: 0,
          behavior: 'smooth'
        });
      });
    }
  }
  
  // تابع منوی موبایل
  function initMobileMenu() {
    const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
    const quickLinks = document.querySelector('.quick-links');
    
    if (!mobileMenuToggle || !quickLinks) return;
    
    mobileMenuToggle.addEventListener('click', function() {
      quickLinks.classList.toggle('active');
      this.textContent = quickLinks.classList.contains('active') ? '✕' : '☰';
    });
  }
  
  // تابع اولیه‌سازی تمام کامپوننت‌ها
  return {
    init: function() {
      initCountdown();
      initSmoothScrolling();
      initLiveChat();
      initArticleToggles();
      initScrollFunctions();
      initMobileMenu();
      
      // Google Analytics
      if (typeof gtag !== 'undefined') {
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', 'GA_MEASUREMENT_ID');
      }
    }
  }
})();

// اجرای کد پس از بارگذاری کامل DOM
document.addEventListener('DOMContentLoaded', function() {
  Dota2Rush.init();
});