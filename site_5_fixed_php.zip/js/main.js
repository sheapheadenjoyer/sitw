/**
 * سیستم پشتیبانی آنلاین - اسکریپت کاربر
 * نسخه 1.0
 */

class SupportSystem {
    constructor() {
        this.userId = this.getUserId();
        this.currentView = 'chat';
        this.unreadMessages = 0;
        this.unreadTickets = 0;
        
        this.initElements();
        this.initEvents();
        this.loadInitialData();
        this.startPolling();
        this.checkAuth();
    }
    
    getUserId() {
        // در حالت واقعی باید از session/cookie خوانده شود
        return document.body.getAttribute('data-user-id') || 1;
    }
    
    initElements() {
        // عناصر چت
        this.chatContainer = document.getElementById('chatContainer');
        this.chatToggle = document.getElementById('chatToggle');
        this.chatBox = document.getElementById('chatBox');
        this.messagesDiv = document.getElementById('messages');
        this.messageInput = document.getElementById('messageInput');
        this.sendBtn = document.getElementById('sendBtn');
        this.unreadBadge = document.getElementById('unreadBadge');
        
        // عناصر تیکت
        this.ticketContainer = document.getElementById('ticketContainer');
        this.ticketToggle = document.getElementById('ticketToggle');
        this.ticketBox = document.getElementById('ticketBox');
        this.ticketList = document.getElementById('ticketList');
        this.newTicketBtn = document.getElementById('newTicketBtn');
        this.ticketUnreadBadge = document.getElementById('ticketUnreadBadge');
        
        // عناصر عمومی
        this.loadingIndicator = document.getElementById('loadingIndicator');
    }
    
    initEvents() {
        // رویدادهای چت
        if (this.chatToggle) {
            this.chatToggle.addEventListener('click', () => this.toggleChat());
        }
        
        if (this.sendBtn) {
            this.sendBtn.addEventListener('click', () => this.sendMessage());
        }
        
        if (this.messageInput) {
            this.messageInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter') this.sendMessage();
            });
        }
        
        // رویدادهای تیکت
        if (this.ticketToggle) {
            this.ticketToggle.addEventListener('click', () => this.toggleTickets());
        }
        
        if (this.newTicketBtn) {
            this.newTicketBtn.addEventListener('click', () => this.showNewTicketForm());
        }
    }
    
    checkAuth() {
        if (!this.userId) {
            this.showLoginPrompt();
        }
    }
    
    showLoginPrompt() {
        const loginHTML = `
            <div class="auth-prompt">
                <p>برای استفاده از پشتیبانی آنلاین باید وارد شوید</p>
                <div class="auth-buttons">
                    <a href="/support/user-login.php" class="btn-login">ورود</a>
                    <a href="/support/register.php" class="btn-register">ثبت نام</a>
                </div>
            </div>
        `;
        
        if (this.chatBox) {
            this.chatBox.innerHTML = loginHTML;
        }
        
        if (this.ticketBox) {
            this.ticketBox.innerHTML = loginHTML;
        }
    }
    
    async loadInitialData() {
        this.showLoading(true);
        
        try {
            if (this.chatBox) {
                await this.loadMessages();
                await this.checkUnreadMessages();
            }
            
            if (this.ticketBox) {
                await this.loadTickets();
                await this.checkUnreadTickets();
            }
        } catch (error) {
            console.error('خطا در بارگذاری داده‌های اولیه:', error);
            this.showError('خطا در بارگذاری داده‌ها');
        } finally {
            this.showLoading(false);
        }
    }
    
    startPolling() {
        this.pollingInterval = setInterval(() => {
            if (this.currentView === 'chat') {
                this.loadMessages();
                this.checkUnreadMessages();
            } else {
                this.loadTickets();
                this.checkUnreadTickets();
            }
        }, 10000); // هر 10 ثانیه
    }
    
    toggleChat() {
        if (!this.userId) {
            this.showLoginPrompt();
            return;
        }
        
        if (this.chatBox.style.display === 'none') {
            this.chatBox.style.display = 'flex';
            this.currentView = 'chat';
            this.loadMessages();
            this.markMessagesAsRead();
        } else {
            this.chatBox.style.display = 'none';
        }
    }
    
    toggleTickets() {
        if (!this.userId) {
            this.showLoginPrompt();
            return;
        }
        
        if (this.ticketBox.style.display === 'none') {
            this.ticketBox.style.display = 'block';
            this.currentView = 'tickets';
            this.loadTickets();
        } else {
            this.ticketBox.style.display = 'none';
        }
    }
    
    async loadMessages() {
        try {
            const response = await fetch(`/support/api/messages?user_id=${this.userId}`);
            
            if (!response.ok) {
                throw new Error('خطا در دریافت پیام‌ها');
            }
            
            const messages = await response.json();
            
            if (messages && messages.length > 0) {
                this.messagesDiv.innerHTML = messages
                    .map(msg => this.createMessageElement(msg))
                    .join('');
                
                this.scrollToBottom();
            } else {
                this.messagesDiv.innerHTML = '<div class="no-messages">هنوز پیامی رد و بدل نشده است</div>';
            }
        } catch (error) {
            console.error('خطا در دریافت پیام‌ها:', error);
            this.messagesDiv.innerHTML = '<div class="error-message">خطا در بارگذاری پیام‌ها</div>';
        }
    }
    
    createMessageElement(message) {
        const isAdmin = message.sender === 'admin';
        return `
            <div class="message ${isAdmin ? 'admin-msg' : 'user-msg'}">
                <div class="message-sender">${isAdmin ? 'پشتیبان' : 'شما'}</div>
                <div class="message-text">${message.text}</div>
                <div class="message-time">${new Date(message.timestamp).toLocaleString('fa-IR')}</div>
            </div>
        `;
    }
    
    async sendMessage() {
        const text = this.messageInput.value.trim();
        if (!text || !this.userId) return;
        
        try {
            const response = await fetch('/support/api/messages', {
                method: 'POST',
                headers: { 
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: JSON.stringify({
                    user_id: this.userId,
                    sender: 'user',
                    text: text
                })
            });
            
            if (response.ok) {
                this.messageInput.value = '';
                this.loadMessages();
            } else {
                throw new Error('خطا در ارسال پیام');
            }
        } catch (error) {
            console.error('خطا در ارسال پیام:', error);
            this.showError('خطا در ارسال پیام. لطفاً مجدداً تلاش کنید.');
        }
    }
    
    async checkUnreadMessages() {
        try {
            const response = await fetch(`/support/api/messages?action=unread_count&user_id=${this.userId}`);
            const data = await response.json();
            
            this.unreadMessages = data.count || 0;
            this.updateUnreadBadges();
        } catch (error) {
            console.error('خطا در بررسی پیام‌های خوانده نشده:', error);
        }
    }
    
    async markMessagesAsRead() {
        try {
            await fetch(`/support/api/messages?action=mark_read&user_id=${this.userId}`, {
                method: 'PATCH'
            });
            this.unreadMessages = 0;
            this.updateUnreadBadges();
        } catch (error) {
            console.error('خطا در علامت‌گذاری پیام‌ها:', error);
        }
    }
    
    async loadTickets() {
        try {
            const response = await fetch(`/support/api/tickets?user_id=${this.userId}`);
            const tickets = await response.json();
            
            if (tickets && tickets.length > 0) {
                this.ticketList.innerHTML = tickets
                    .map(ticket => this.createTicketElement(ticket))
                    .join('');
                
                this.addTicketEvents();
            } else {
                this.ticketList.innerHTML = '<div class="no-tickets">تیکتی یافت نشد</div>';
            }
        } catch (error) {
            console.error('خطا در دریافت تیکت‌ها:', error);
            this.ticketList.innerHTML = '<div class="error">خطا در بارگذاری تیکت‌ها</div>';
        }
    }
    
    createTicketElement(ticket) {
        return `
            <div class="ticket-item ${ticket.status}" data-id="${ticket.id}">
                <div class="ticket-header">
                    <span class="ticket-subject">${ticket.subject}</span>
                    <span class="ticket-status ${ticket.status}">
                        ${this.getStatusText(ticket.status)}
                    </span>
                </div>
                <div class="ticket-excerpt">${ticket.message.substring(0, 100)}...</div>
                <div class="ticket-meta">
                    <span class="ticket-priority ${ticket.priority}">
                        ${this.getPriorityText(ticket.priority)}
                    </span>
                    <small>${new Date(ticket.created_at).toLocaleString('fa-IR')}</small>
                </div>
            </div>
        `;
    }
    
    addTicketEvents() {
        document.querySelectorAll('.ticket-item').forEach(item => {
            item.addEventListener('click', () => {
                const ticketId = item.getAttribute('data-id');
                this.showTicketDetails(ticketId);
            });
        });
    }
    
    async showTicketDetails(ticketId) {
        try {
            // در حالت واقعی باید یک مودال نمایش داده شود
            window.location.href = `/support/tickets.php?action=view&id=${ticketId}`;
        } catch (error) {
            console.error('خطا در نمایش جزئیات تیکت:', error);
            this.showError('خطا در نمایش تیکت');
        }
    }
    
    showNewTicketForm() {
        // در حالت واقعی باید یک مودال نمایش داده شود
        window.location.href = '/support/tickets.php?action=new';
    }
    
    async checkUnreadTickets() {
        try {
            const response = await fetch(`/support/api/tickets?action=counts&user_id=${this.userId}`);
            const counts = await response.json();
            
            this.unreadTickets = counts.open || 0;
            this.updateUnreadBadges();
        } catch (error) {
            console.error('خطا در بررسی تیکت‌های خوانده نشده:', error);
        }
    }
    
    updateUnreadBadges() {
        // به‌روزرسانی نشانگر پیام‌های خوانده نشده
        if (this.unreadBadge) {
            if (this.unreadMessages > 0) {
                this.unreadBadge.textContent = this.unreadMessages;
                this.unreadBadge.style.display = 'flex';
            } else {
                this.unreadBadge.style.display = 'none';
            }
        }
        
        // به‌روزرسانی نشانگر تیکت‌های خوانده نشده
        if (this.ticketUnreadBadge) {
            if (this.unreadTickets > 0) {
                this.ticketUnreadBadge.textContent = this.unreadTickets;
                this.ticketUnreadBadge.style.display = 'flex';
            } else {
                this.ticketUnreadBadge.style.display = 'none';
            }
        }
    }
    
    getStatusText(status) {
        const statusMap = {
            'open': 'باز',
            'pending': 'در حال بررسی',
            'closed': 'بسته شده'
        };
        return statusMap[status] || status;
    }
    
    getPriorityText(priority) {
        const priorityMap = {
            'low': 'کم',
            'medium': 'متوسط',
            'high': 'بالا'
        };
        return priorityMap[priority] || priority;
    }
    
    scrollToBottom() {
        if (this.messagesDiv) {
            this.messagesDiv.scrollTop = this.messagesDiv.scrollHeight;
        }
    }
    
    showLoading(show) {
        if (this.loadingIndicator) {
            this.loadingIndicator.style.display = show ? 'flex' : 'none';
        }
    }
    
    showError(message) {
        const errorDiv = document.createElement('div');
        errorDiv.className = 'error-message';
        errorDiv.textContent = message;
        
        if (this.currentView === 'chat' && this.chatBox) {
            this.chatBox.prepend(errorDiv);
        } else if (this.ticketBox) {
            this.ticketBox.prepend(errorDiv);
        }
        
        setTimeout(() => {
            errorDiv.remove();
        }, 5000);
    }
    
    showNotification(title, message) {
        if (!('Notification' in window)) return;
        
        if (Notification.permission === 'granted') {
            new Notification(title, { body: message });
        } else if (Notification.permission !== 'denied') {
            Notification.requestPermission().then(permission => {
                if (permission === 'granted') {
                    new Notification(title, { body: message });
                }
            });
        }
    }
}

// راه‌اندازی سیستم هنگام بارگذاری صفحه
document.addEventListener('DOMContentLoaded', () => {
    const supportSystem = new SupportSystem();
    
    // برای دسترسی از کنسول توسعه‌دهندگان
    window.SupportSystem = supportSystem;
});