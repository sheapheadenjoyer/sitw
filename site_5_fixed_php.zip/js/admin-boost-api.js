// admin-boost-api.js - مدیریت بوستینگ در پنل ادمین

/**
 * ماژول مدیریت بوستینگ در پنل ادمین
 */
const AdminBoostModule = (() => {
  // بارگیری سفارشات بوست
  const loadBoostOrders = async () => {
    try {
      const response = await fetch('/admin/api/boosts/orders');
      const data = await response.json();
      renderBoostOrders(data.orders);
    } catch (error) {
      console.error('Error loading boost orders:', error);
      showError('خطا در بارگیری سفارشات بوست');
    }
  };

  // نمایش سفارشات در جدول
  const renderBoostOrders = (orders) => {
    const tableBody = document.getElementById('boost-orders-body');
    tableBody.innerHTML = '';
    
    orders.forEach(order => {
      const row = document.createElement('tr');
      row.innerHTML = `
        <td>${order.id}</td>
        <td>${order.customer}</td>
        <td>${order.currentRank} → ${order.targetRank}</td>
        <td>${order.booster || 'تعیین نشده'}</td>
        <td>${order.progress}%</td>
        <td><span class="status-badge ${getStatusClass(order.status)}">${order.status}</span></td>
        <td>
          <button class="btn btn-sm btn-primary assign-booster" data-id="${order.id}">انتخاب بوستر</button>
          <button class="btn btn-sm btn-info view-details" data-id="${order.id}">جزئیات</button>
        </td>
      `;
      tableBody.appendChild(row);
    });
    
    setupBoostButtons();
  };

  // تنظیم رویدادهای دکمه‌ها
  const setupBoostButtons = () => {
    // دکمه انتصاب بوستر
    document.querySelectorAll('.assign-booster').forEach(btn => {
      btn.addEventListener('click', function() {
        const orderId = this.dataset.id;
        showBoosterAssignmentModal(orderId);
      });
    });
    
    // دکمه مشاهده جزئیات
    document.querySelectorAll('.view-details').forEach(btn => {
      btn.addEventListener('click', function() {
        const orderId = this.dataset.id;
        showOrderDetails(orderId);
      });
    });
  };

  // نمایش مدال انتصاب بوستر
  const showBoosterAssignmentModal = (orderId) => {
    // در اینجا می‌توانید لیست بوسترها را از سرور دریافت کنید
    const boosters = [
      {id: 1, name: 'بوستر یک', rank: 'Immortal'},
      {id: 2, name: 'بوستر دو', rank: 'Divine 5'},
      {id: 3, name: 'بوستر سه', rank: 'Divine 3'}
    ];
    
    const modalContent = `
      <div class="modal-header">
        <h5>انتخاب بوستر برای سفارش #${orderId}</h5>
      </div>
      <div class="modal-body">
        <div class="form-group">
          <label>بوسترهای موجود:</label>
          <select class="form-control" id="booster-select">
            ${boosters.map(booster => 
              `<option value="${booster.id}">${booster.name} (${booster.rank})</option>`
            ).join('')}
          </select>
        </div>
        <div class="form-group">
          <label>زمان تخمینی تکمیل:</label>
          <input type="datetime-local" class="form-control" id="completion-time">
        </div>
      </div>
      <div class="modal-footer">
        <button class="btn btn-secondary" data-dismiss="modal">انصراف</button>
        <button class="btn btn-primary" id="confirm-assignment">تایید انتصاب</button>
      </div>
    `;
    
    showModal('انتخاب بوستر', modalContent);
    
    // رویداد تایید انتصاب
    document.getElementById('confirm-assignment').addEventListener('click', async () => {
      const boosterId = document.getElementById('booster-select').value;
      const completionTime = document.getElementById('completion-time').value;
      
      try {
        const response = await assignBoosterToOrder(orderId, boosterId, completionTime);
        showSuccess('بوستر با موفقیت انتصاب یافت');
        loadBoostOrders(); // بارگیری مجدد لیست
      } catch (error) {
        showError('خطا در انتصاب بوستر');
      }
    });
  };

  // انتصاب بوستر به سفارش
  const assignBoosterToOrder = async (orderId, boosterId, completionTime) => {
    const response = await fetch('/admin/api/boosts/assign', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({orderId, boosterId, completionTime})
    });
    
    return response.json();
  };

  // نمایش جزئیات سفارش
  const showOrderDetails = async (orderId) => {
    try {
      const response = await fetch(`/admin/api/boosts/orders/${orderId}`);
      const order = await response.json();
      
      const detailsContent = `
        <div class="order-details">
          <div class="detail-row">
            <span class="detail-label">مشتری:</span>
            <span class="detail-value">${order.customer}</span>
          </div>
          <div class="detail-row">
            <span class="detail-label">رنک فعلی:</span>
            <span class="detail-value">${order.currentRank}</span>
          </div>
          <div class="detail-row">
            <span class="detail-label">رنک هدف:</span>
            <span class="detail-value">${order.targetRank}</span>
          </div>
          <div class="detail-row">
            <span class="detail-label">پوزیشن:</span>
            <span class="detail-value">${order.position}</span>
          </div>
          <div class="detail-row">
            <span class="detail-label">وضعیت:</span>
            <span class="detail-value ${getStatusClass(order.status)}">${order.status}</span>
          </div>
          <div class="detail-row">
            <span class="detail-label">پیشرفت:</span>
            <div class="progress">
              <div class="progress-bar" role="progressbar" style="width: ${order.progress}%" 
                   aria-valuenow="${order.progress}" aria-valuemin="0" aria-valuemax="100">
                ${order.progress}%
              </div>
            </div>
          </div>
          ${order.booster ? `
          <div class="detail-row">
            <span class="detail-label">بوستر:</span>
            <span class="detail-value">${order.booster}</span>
          </div>
          ` : ''}
          ${order.notes ? `
          <div class="detail-row">
            <span class="detail-label">یادداشت‌ها:</span>
            <p class="detail-value">${order.notes}</p>
          </div>
          ` : ''}
        </div>
      `;
      
      showModal(`جزئیات سفارش #${orderId}`, detailsContent);
    } catch (error) {
      showError('خطا در دریافت جزئیات سفارش');
    }
  };

  // تابع کمکی برای کلاس وضعیت
  const getStatusClass = (status) => {
    switch(status.toLowerCase()) {
      case 'تکمیل شده': return 'status-completed';
      case 'در حال انجام': return 'status-pending';
      case 'لغو شده': return 'status-rejected';
      default: return '';
    }
  };

  return {
    init: () => {
      loadBoostOrders();
      console.log('Admin Boost Module initialized');
    }
  };
})();

// مقداردهی اولیه هنگام بارگذاری صفحه
document.addEventListener('DOMContentLoaded', () => {
  AdminBoostModule.init();
});