// متغیرهای کاربر
let userData = {};

function loadUserData() {
  fetch('backend/get_user_panel_data.php')
    .then(res => res.json())
    .then(data => {
      if (data.error) {
        alert("خطا در دریافت اطلاعات کاربر");
        return;
      }
      userData = data;
      updateUI();
    });
}


// اعلان‌ها
let notifications = [
    {
        id: 1,
        title: "تبریک! شما به رنک Divine رسیدید",
        time: "2 ساعت پیش",
        icon: "fas fa-trophy",
        read: false
    },
    {
        id: 2,
        title: "درخواست جدید برای پیوستن به تیم شما",
        time: "دیروز، 18:45",
        icon: "fas fa-users",
        read: false
    },
    {
        id: 3,
        title: "مسابقه فردا ساعت 20:30 شروع می‌شود",
        time: "2 روز پیش",
        icon: "fas fa-calendar",
        read: true
    }
];

// ذخیره اطلاعات در localStorage
function saveUserData() {
    localStorage.setItem('dota2rush_userData', JSON.stringify(userData));
    localStorage.setItem('dota2rush_notifications', JSON.stringify(notifications));
}

// بارگذاری اطلاعات از localStorage
function loadUserData() {
    const savedUserData = localStorage.getItem('dota2rush_userData');
    const savedNotifications = localStorage.getItem('dota2rush_notifications');
    
    if (savedUserData) {
        userData = JSON.parse(savedUserData);
    }
    
    if (savedNotifications) {
        notifications = JSON.parse(savedNotifications);
    }
    
    updateUI();
}

// به‌روزرسانی UI با اطلاعات کاربر
function updateUI() {
    // اطلاعات پروفایل
    document.getElementById('profileName').textContent = userData.fullName;
    document.getElementById('profileEmail').textContent = userData.email;
    document.getElementById('displayName').textContent = userData.fullName;
    document.getElementById('displayEmail').textContent = userData.email;
    document.getElementById('displayBio').textContent = userData.bio;
    document.getElementById('displayJoinDate').textContent = userData.joinDate;
    document.getElementById('displayLastActivity').textContent = userData.lastActivity;
    document.getElementById('displayMatches').textContent = userData.matches;
    document.getElementById('displayWinRate').textContent = userData.winRate;
    
    // موقعیت و رنک
    const positionText = getPositionText(userData.position);
    document.getElementById('displayPosition').textContent = positionText;
    document.getElementById('displayRank').textContent = userData.rank;
    
    // فرم تنظیمات
    document.getElementById('fullName').value = userData.fullName;
    document.getElementById('username').value = userData.username;
    document.getElementById('email').value = userData.email;
    document.getElementById('phone').value = userData.phone;
    document.getElementById('bio').value = userData.bio;
    document.getElementById('rankSelect').value = userData.rank;
    
    // انتخاب موقعیت
    const positionButtons = document.querySelectorAll('#positionButtons button');
    positionButtons.forEach(button => {
        if (button.dataset.position === userData.position) {
            button.classList.add('active');
        } else {
            button.classList.remove('active');
        }
    });
    
    // آواتار
    if (userData.avatar) {
        document.getElementById('currentAvatar').innerHTML = `<img src="images/${userData.avatar}" alt="آواتار انتخابی" style="width:100%;height:100%;object-fit:cover">`;
        document.getElementById('profileAvatarDisplay').innerHTML = `<img src="images/${userData.avatar}" alt="آواتار انتخابی" style="width:100%;height:100%;object-fit:cover">`;
    } else {
        document.getElementById('currentAvatar').textContent = userData.fullName.charAt(0);
        document.getElementById('profileAvatarDisplay').textContent = userData.fullName.charAt(0);
    }
    
    // اعلان‌ها
    updateNotificationBadge();
    renderNotifications();
}

// دریافت متن موقعیت
function getPositionText(position) {
    switch(position) {
        case "1": return "پوزیشن 1 (Carry)";
        case "2": return "پوزیشن 2 (Mid)";
        case "3": return "پوزیشن 3 (Offlane)";
        case "4": return "پوزیشن 4 (Support)";
        case "5": return "پوزیشن 5 (Hard Support)";
        default: return "تعیین نشده";
    }
}

// به‌روزرسانی نشانگر اعلان‌ها
function updateNotificationBadge() {
    const unreadCount = notifications.filter(n => !n.read).length;
    const badge = document.getElementById('notificationCount');
    badge.textContent = unreadCount;
    badge.style.display = unreadCount > 0 ? 'flex' : 'none';
}

// نمایش اعلان‌ها
function renderNotifications() {
    const notificationList = document.getElementById('notificationList');
    notificationList.innerHTML = '';
    
    notifications.forEach(notif => {
        const notifItem = document.createElement('div');
        notifItem.className = `notification-item ${notif.read ? '' : 'unread'}`;
        notifItem.innerHTML = `
            <div class="notif-icon"><i class="${notif.icon}"></i></div>
            <div class="notif-content">
                <p class="notif-title">${notif.title}</p>
                <p class="notif-time">${notif.time}</p>
            </div>
        `;
        notifItem.addEventListener('click', () => markAsRead(notif.id));
        notificationList.appendChild(notifItem);
    });
}

// علامت‌گذاری به عنوان خوانده شده
function markAsRead(id) {
    const notification = notifications.find(n => n.id === id);
    if (notification && !notification.read) {
        notification.read = true;
        saveUserData();
        updateNotificationBadge();
        renderNotifications();
    }
}

// علامت‌گذاری همه اعلان‌ها به عنوان خوانده شده
function markAllAsRead() {
    notifications.forEach(notif => {
        if (!notif.read) {
            notif.read = true;
        }
    });
    saveUserData();
    updateNotificationBadge();
    renderNotifications();
}

// ذخیره تنظیمات پروفایل
function saveProfileSettings() {
    const formData = new FormData();
    formData.append('full_name', document.getElementById('fullName').value);
    formData.append('username', document.getElementById('username').value);
    formData.append('email', document.getElementById('email').value);
    formData.append('phone', document.getElementById('phone').value);
    formData.append('bio', document.getElementById('bio').value);
    formData.append('position', userData.position);
    formData.append('rank', document.getElementById('rankSelect').value);

    fetch('backend/save_profile.php', {
        method: 'POST',
        body: formData
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            const newPassword = document.getElementById('newPassword').value;
            const confirmPassword = document.getElementById('confirmPassword').value;
            if (newPassword && newPassword === confirmPassword) {
                const passForm = new FormData();
                passForm.append('current_password', document.getElementById('currentPassword').value);
                passForm.append('new_password', newPassword);
                fetch('backend/change_password.php', {
                    method: 'POST',
                    body: passForm
                })
                .then(res => res.json())
                .then(passRes => {
                    if (passRes.success) {
                        alert('رمز عبور با موفقیت تغییر یافت!');
                    } else {
                        alert('رمز فعلی نادرست است!');
                    }
                });
            }
            alert('تغییرات با موفقیت ذخیره شد!');
            loadUserData();
            document.getElementById('newPassword').value = '';
            document.getElementById('confirmPassword').value = '';
            document.getElementById('currentPassword').value = '';
        } else {
            alert('خطا در ذخیره تنظیمات!');
        }
    });
}

// انتخاب آواتار
function setupAvatarSelection() {
    const avatarOptions = document.querySelectorAll('.avatar-option');
    
    avatarOptions.forEach(option => {
        option.addEventListener('click', () => {
            // Remove selected class from all options
            avatarOptions.forEach(opt => opt.classList.remove('selected'));
            
            // Add selected class to clicked option
            option.classList.add('selected');
            
            // Get the image path
            const imgPath = option.getAttribute('data-img');
            userData.avatar = imgPath;
        });
    });
}

// انتخاب موقعیت
function setupPositionSelection() {
    const positionButtons = document.querySelectorAll('#positionButtons button');
    
    positionButtons.forEach(button => {
        button.addEventListener('click', (e) => {
            e.preventDefault();
            positionButtons.forEach(btn => btn.classList.remove('active'));
            button.classList.add('active');
            userData.position = button.dataset.position;
        });
    });
}

// مدیریت تم
function setupThemeToggle() {
    const themeToggle = document.getElementById('themeToggle');
    const body = document.body;

    themeToggle.addEventListener('click', () => {
        body.classList.toggle('light-theme');
        if (body.classList.contains('light-theme')) {
            localStorage.setItem('theme', 'light');
            themeToggle.innerHTML = '<i class="fas fa-sun"></i>';
        } else {
            localStorage.setItem('theme', 'dark');
            themeToggle.innerHTML = '<i class="fas fa-moon"></i>';
        }
    });

    // بارگذاری تم ذخیره شده
    if (localStorage.getItem('theme') === 'light') {
        body.classList.add('light-theme');
        themeToggle.innerHTML = '<i class="fas fa-sun"></i>';
    }
}

// مدیریت تب‌ها
function setupTabs() {
    document.querySelectorAll('.menu-link').forEach(link => {
        link.addEventListener('click', (e) => {
            const tabId = link.getAttribute('data-tab');
            if (tabId) {
                e.preventDefault();
                document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
                document.getElementById(tabId).classList.add('active');
                
                // Update active menu item
                document.querySelectorAll('.menu-link').forEach(item => item.classList.remove('active'));
                link.classList.add('active');
            }
        });
    });
}

// مدیریت اعلان‌ها
function setupNotifications() {
    const notificationBell = document.getElementById('notificationBell');
    const notificationModal = document.getElementById('notificationModal');
    const closeModal = document.querySelector('.close-modal');
    const markAllReadBtn = document.getElementById('markAllRead');
    
    notificationBell.addEventListener('click', () => {
        notificationModal.style.display = 'block';
    });
    
    closeModal.addEventListener('click', () => {
        notificationModal.style.display = 'none';
    });
    
    markAllReadBtn.addEventListener('click', () => {
        markAllAsRead();
    });
    
    window.addEventListener('click', (e) => {
        if (e.target === notificationModal) {
            notificationModal.style.display = 'none';
        }
    });
}

// مدیریت رویدادهای فرم
function setupFormEvents() {
    const saveBtn = document.getElementById('saveBtn');
    const cancelBtn = document.getElementById('cancelBtn');
    
    saveBtn.addEventListener('click', (e) => {
        e.preventDefault();
        saveProfileSettings();
    });
    
    cancelBtn.addEventListener('click', (e) => {
        e.preventDefault();
        // بازگشت به تب پروفایل بدون ذخیره تغییرات
        document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
        document.getElementById('dashboard').classList.add('active');
        
        document.querySelectorAll('.menu-link').forEach(item => item.classList.remove('active'));
        document.querySelector('.menu-link[data-tab="dashboard"]').classList.add('active');
    });
}

// مدیریت خروج
function setupLogout() {
    const logoutBtn = document.getElementById('logoutBtn');
    
    logoutBtn.addEventListener('click', (e) => {
        e.preventDefault();
        if (confirm('آیا مطمئن هستید که می‌خواهید خارج شوید؟')) {
            // در اینجا می‌توانید عملیات خروج را انجام دهید
            alert('با موفقیت خارج شدید!');
            // ریدایرکت به صفحه ورود
            window.location.href = 'login.html';
        }
    });
}

// مقداردهی اولیه
document.addEventListener('DOMContentLoaded', () => {
    loadUserData();
    setupThemeToggle();
    setupTabs();
    setupAvatarSelection();
    setupPositionSelection();
    setupNotifications();
    setupFormEvents();
    setupLogout();
    setupAvatarUpload();
    
    // انتخاب موقعیت پیش‌فرض
    const defaultPositionBtn = document.querySelector(`#positionButtons button[data-position="${userData.position}"]`);
    if (defaultPositionBtn) {
        defaultPositionBtn.classList.add('active');
    }
    
    // انتخاب آواتار اگر وجود دارد
    if (userData.avatar) {
        const avatarOption = document.querySelector(`.avatar-option[data-img="${userData.avatar}"]`);
        if (avatarOption) {
            avatarOption.classList.add('selected');
        }
    }
});

// مدیریت آپلود آواتار
function setupAvatarUpload() {
    const avatarInput = document.getElementById('avatarInput');
    avatarInput.addEventListener('change', function() {
        const formData = new FormData();
        formData.append('avatar', avatarInput.files[0]);
        fetch('backend/upload_avatar.php', {
            method: 'POST',
            body: formData
        })
        .then(res => res.json())
        .then(data => {
            if (data.success) {
                userData.avatar = data.avatar;
                loadUserData();
            } else {
                alert('آپلود آواتار با خطا مواجه شد!');
            }
        });
    });
}
