
CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    type ENUM('boost', 'coach') NOT NULL,
    data JSON NOT NULL,
    telegram_id VARCHAR(100),
    phone VARCHAR(20),
    note TEXT,
    price INT,
    status ENUM('pending', 'paid', 'failed') DEFAULT 'pending',
    tracking_code VARCHAR(50),
    payment_date DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
