async function loadMessages() {
  const res = await fetch('/api/get-messages.php');
  const messages = await res.json();

  const container = document.getElementById('messageList');
  if (!messages.length) {
    container.innerHTML = '<p>پیامی یافت نشد.</p>';
    return;
  }

  container.innerHTML = messages.map(msg => `
    <div class="message-item">
      <b>کاربر #${msg.user_id}</b> - ${new Date(msg.created_at).toLocaleString('fa-IR')}
      <p>${msg.text}</p>
      <button onclick="replyToMessage(${msg.id})">پاسخ</button>
    </div>
  `).join('');
}

async function replyToMessage(id) {
  const text = prompt("پاسخ شما:");
  if (!text) return;
  const res = await fetch('/api/reply-message.php', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ id, text })
  });
  loadMessages();
}

async function loadOrders() {
  const res = await fetch('/api/get-orders.php');
  const orders = await res.json();

  const container = document.getElementById('orderList');
  if (!orders.length) {
    container.innerHTML = '<p>سفارشی یافت نشد.</p>';
    return;
  }

  container.innerHTML = orders.map(order => `
    <div class="order-item">
      <b>سفارش #${order.id}</b> | مبلغ: ${order.amount} تومان
      <p>توضیح: ${order.description}</p>
      <p>شماره: ${order.phone} | تلگرام: ${order.telegram_id}</p>
      <p><i>در تاریخ ${new Date(order.created_at).toLocaleString('fa-IR')}</i></p>
    </div>
  `).join('');
}

document.addEventListener('DOMContentLoaded', () => {
  loadMessages();
  loadOrders();
});
