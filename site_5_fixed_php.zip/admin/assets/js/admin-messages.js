// بارگذاری پیام‌های پشتیبانی
function loadSupportMessages() {
    fetch('admin/get-messages.php')
        .then(response => response.json())
        .then(messages => {
            const tableBody = document.querySelector('#supportMessagesTable tbody');
            tableBody.innerHTML = '';
            let unreadCount = 0;
            messages.forEach(message => {
                const row = document.createElement('tr');
                row.dataset.messageId = message.id;
                if (!message.is_read) {
                    unreadCount++;
                    row.style.backgroundColor = '#fff8e1';
                }
                row.innerHTML = `
                    <td>${message.username}</td>
                    <td>${message.message}</td>
                    <td>${new Date(message.created_at).toLocaleString('fa-IR')}</td>
                    <td>
                        <button class="btn btn-primary btn-sm reply-btn" data-user-id="${message.user_id}">
                            <i class="fas fa-reply"></i> پاسخ
                        </button>
                    </td>
                `;
                tableBody.appendChild(row);
            });
            document.getElementById('unreadMessagesBadge').textContent = unreadCount;
            setupReplyButtons();
        });
}

function setupReplyButtons() {
    document.querySelectorAll('.reply-btn').forEach(button => {
        button.addEventListener('click', function() {
            const userId = this.dataset.userId;
            const message = prompt('پاسخ خود را وارد کنید:');
            if (message) {
                fetch('admin/reply-message.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ user_id: userId, message: message })
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('پاسخ با موفقیت ارسال شد');
                        loadSupportMessages();
                    }
                });
            }
        });
    });
}

setInterval(loadSupportMessages, 30000);
document.addEventListener('DOMContentLoaded', function() {
    loadSupportMessages();
});
