/**
 * سیستم پشتیبانی آنلاین - اسکریپت ادمین
 * نسخه 1.0
 */

class AdminSupportSystem {
    constructor() {
        this.currentSection = this.getCurrentSection();
        this.initElements();
        this.initEvents();
        this.loadInitialData();
    }
    
    getCurrentSection() {
        const path = window.location.pathname;
        if (path.includes('admin-tickets.php')) return 'tickets';
        if (path.includes('admin-users.php')) return 'users';
        return 'messages'; // پیش‌فرض
    }
    
    initElements() {
        // عناصر مشترک
        this.loadingIndicator = document.getElementById('loadingIndicator');
        this.notificationArea = document.getElementById('notificationArea');
        
        // عناصر بخش پیام‌ها
        this.messageList = document.getElementById('messageList');
        this.messageStatusFilter = document.getElementById('messageStatusFilter');
        this.messageUserFilter = document.getElementById('messageUserFilter');
        this.messageSearchInput = document.getElementById('messageSearchInput');
        
        // عناصر بخش تیکت‌ها
        this.ticketList = document.getElementById('ticketList');
        this.ticketStatusFilter = document.getElementById('ticketStatusFilter');
        this.ticketPriorityFilter = document.getElementById('ticketPriorityFilter');
        
        // عناصر بخش کاربران
        this.userList = document.getElementById('userList');
        this.userSearchInput = document.getElementById('userSearchInput');
    }
    
    initEvents() {
        // رویدادهای فیلتر پیام‌ها
        if (this.messageStatusFilter) {
            this.messageStatusFilter.addEventListener('change', () => this.loadMessages());
        }
        
        if (this.messageUserFilter) {
            this.messageUserFilter.addEventListener('change', () => this.loadMessages());
        }
        
        if (this.messageSearchInput) {
            this.messageSearchInput.addEventListener('input', () => this.searchMessages());
        }
        
        // رویدادهای فیلتر تیکت‌ها
        if (this.ticketStatusFilter) {
            this.ticketStatusFilter.addEventListener('change', () => this.loadTickets());
        }
        
        if (this.ticketPriorityFilter) {
            this.ticketPriorityFilter.addEventListener('change', () => this.loadTickets());
        }
        
        // رویدادهای جستجوی کاربران
        if (this.userSearchInput) {
            this.userSearchInput.addEventListener('input', () => this.searchUsers());
        }
    }
    
    async loadInitialData() {
        this.showLoading(true);
        
        try {
            switch (this.currentSection) {
                case 'messages':
                    await this.loadMessageUsers();
                    await this.loadMessages();
                    break;
                    
                case 'tickets':
                    await this.loadTickets();
                    break;
                    
                case 'users':
                    await this.loadUsers();
                    break;
            }
        } catch (error) {
            console.error('خطا در بارگذاری داده‌های اولیه:', error);
            this.showError('خطا در بارگذاری داده‌ها');
        } finally {
            this.showLoading(false);
        }
    }
    
    async loadMessages() {
        try {
            const status = this.messageStatusFilter ? this.messageStatusFilter.value : 'all';
            const userId = this.messageUserFilter ? this.messageUserFilter.value : 'all';
            
            const response = await fetch(`/support/api/messages?status=${status}&user_id=${userId}`);
            const messages = await response.json();
            
            this.renderMessages(messages);
        } catch (error) {
            console.error('خطا در دریافت پیام‌ها:', error);
            this.showError('خطا در بارگذاری پیام‌ها');
        }
    }
    
    renderMessages(messages) {
        if (!messages || messages.length === 0) {
            this.messageList.innerHTML = '<div class="no-data">پیامی یافت نشد</div>';
            return;
        }
        
        this.messageList.innerHTML = messages.map(msg => `
            <div class="message-item ${msg.status}" data-id="${msg.id}">
                <div class="message-header">
                    <span class="message-sender">${msg.user_id ? `کاربر #${msg.user_id}` : 'سیستم'}</span>
                    <span class="message-time">${new Date(msg.timestamp).toLocaleString('fa-IR')}</span>
                    ${msg.status === 'unread' ? '<span class="badge new">جدید</span>' : ''}
                </div>
                <div class="message-text">${msg.text}</div>
                <div class="message-actions">
                    <button class="btn btn-reply" data-id="${msg.id}">
                        <i class="fas fa-reply"></i> پاسخ
                    </button>
                    ${msg.status === 'unread' ? `
                    <button class="btn btn-mark-read" data-id="${msg.id}">
                        <i class="fas fa-check"></i> خوانده شده
                    </button>
                    ` : ''}
                </div>
            </div>
        `).join('');
        
        this.addMessageEvents();
    }
    
    addMessageEvents() {
        document.querySelectorAll('.btn-reply').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const messageId = e.currentTarget.getAttribute('data-id');
                this.replyToMessage(messageId);
            });
        });
        
        document.querySelectorAll('.btn-mark-read').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const messageId = e.currentTarget.getAttribute('data-id');
                this.markMessageAsRead(messageId);
            });
        });
    }
    
    async replyToMessage(messageId) {
        const replyText = prompt('پاسخ خود را وارد کنید:');
        if (!replyText) return;
        
        try {
            const response = await fetch('/support/api/messages', {
                method: 'POST',
                headers: { 
                    'Content-Type': 'application/json',
                    'X-Requested-With': 'XMLHttpRequest'
                },
                body: JSON.stringify({
                    reply_to: messageId,
                    sender: 'admin',
                    text: replyText
                })
            });
            
            if (response.ok) {
                this.showSuccess('پاسخ با موفقیت ارسال شد');
                this.loadMessages();
            } else {
                throw new Error('خطا در ارسال پاسخ');
            }
        } catch (error) {
            console.error('خطا در ارسال پاسخ:', error);
            this.showError('خطا در ارسال پاسخ');
        }
    }
    
    async markMessageAsRead(messageId) {
        try {
            const response = await fetch(`/support/api/messages/${messageId}/read`, {
                method: 'PATCH'
            });
            
            if (response.ok) {
                this.loadMessages();
            }
        } catch (error) {
            console.error('خطا در علامت‌گذاری پیام:', error);
        }
    }
    
    async loadMessageUsers() {
        try {
            const response = await fetch('/support/api/users');
            const users = await response.json();
            
            if (this.messageUserFilter) {
                users.forEach(user => {
                    const option = document.createElement('option');
                    option.value = user.id;
                    option.textContent = user.username || `کاربر ${user.id}`;
                    this.messageUserFilter.appendChild(option);
                });
            }
        } catch (error) {
            console.error('خطا در دریافت کاربران:', error);
        }
    }
    
    async searchMessages() {
        const query = this.messageSearchInput.value.trim();
        if (query.length < 2) return;
        
        try {
            const response = await fetch(`/support/api/messages/search?q=${encodeURIComponent(query)}`);
            const messages = await response.json();
            this.renderMessages(messages);
        } catch (error) {
            console.error('خطا در جستجوی پیام‌ها:', error);
        }
    }
    
    async loadTickets() {
        try {
            const status = this.ticketStatusFilter ? this.ticketStatusFilter.value : 'all';
            const priority = this.ticketPriorityFilter ? this.ticketPriorityFilter.value : 'all';
            
            const response = await fetch(`/support/api/tickets?status=${status}&priority=${priority}`);
            const tickets = await response.json();
            
            this.renderTickets(tickets);
        } catch (error) {
            console.error('خطا در دریافت تیکت‌ها:', error);
            this.showError('خطا در بارگذاری تیکت‌ها');
        }
    }
    
    renderTickets(tickets) {
        if (!tickets || tickets.length === 0) {
            this.ticketList.innerHTML = '<div class="no-data">تیکتی یافت نشد</div>';
            return;
        }
        
        this.ticketList.innerHTML = tickets.map(ticket => `
            <div class="ticket-item ${ticket.status}" data-id="${ticket.id}">
                <div class="ticket-header">
                    <span class="ticket-subject">${ticket.subject}</span>
                    <span class="ticket-meta">
                        <span class="ticket-user">کاربر #${ticket.user_id}</span>
                        <span class="ticket-status ${ticket.status}">${this.getStatusText(ticket.status)}</span>
                        <span class="ticket-priority ${ticket.priority}">${this.getPriorityText(ticket.priority)}</span>
                    </span>
                </div>
                <div class="ticket-excerpt">${ticket.message.substring(0, 120)}...</div>
                <div class="ticket-footer">
                    <span class="ticket-date">${new Date(ticket.created_at).toLocaleString('fa-IR')}</span>
                    <div class="ticket-actions">
                        <a href="/support/admin-tickets.php?action=view&id=${ticket.id}" class="btn btn-view">
                            <i class="fas fa-eye"></i> مشاهده
                        </a>
                        <button class="btn btn-change-status" data-id="${ticket.id}">
                            <i class="fas fa-sync-alt"></i> تغییر وضعیت
                        </button>
                    </div>
                </div>
            </div>
        `).join('');
        
        this.addTicketEvents();
    }
    
    addTicketEvents() {
        document.querySelectorAll('.btn-change-status').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const ticketId = e.currentTarget.getAttribute('data-id');
                this.changeTicketStatus(ticketId);
            });
        });
    }
    
    async changeTicketStatus(ticketId) {
        const newStatus = prompt('وضعیت جدید را وارد کنید (open, pending, closed):');
        if (!newStatus || !['open', 'pending', 'closed'].includes(newStatus)) return;
        
        try {
            const response = await fetch(`/support/api/tickets/${ticketId}/status`, {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ status: newStatus })
            });
            
            if (response.ok) {
                this.showSuccess('وضعیت تیکت با موفقیت تغییر یافت');
                this.loadTickets();
            }
        } catch (error) {
            console.error('خطا در تغییر وضعیت تیکت:', error);
            this.showError('خطا در تغییر وضعیت تیکت');
        }
    }
    
    async loadUsers() {
        try {
            const response = await fetch('/support/api/users');
            const users = await response.json();
            this.renderUsers(users);
        } catch (error) {
            console.error('خطا در دریافت کاربران:', error);
            this.showError('خطا در بارگذاری کاربران');
        }
    }
    
    renderUsers(users) {
        if (!users || users.length === 0) {
            this.userList.innerHTML = '<div class="no-data">کاربری یافت نشد</div>';
            return;
        }
        
        this.userList.innerHTML = users.map(user => `
            <div class="user-item" data-id="${user.id}">
                <div class="user-avatar">
                    <i class="fas fa-user-circle"></i>
                </div>
                <div class="user-info">
                    <div class="user-name">${user.username || `کاربر ${user.id}`}</div>
                    <div class="user-email">${user.email || 'بدون ایمیل'}</div>
                    <div class="user-meta">
                        <span class="user-join-date">عضویت: ${new Date(user.created_at).toLocaleDateString('fa-IR')}</span>
                        <span class="user-tickets-count">تیکت‌ها: ${user.tickets_count || 0}</span>
                    </div>
                </div>
                <div class="user-actions">
                    <button class="btn btn-edit-user" data-id="${user.id}">
                        <i class="fas fa-edit"></i> ویرایش
                    </button>
                    <button class="btn btn-delete-user" data-id="${user.id}">
                        <i class="fas fa-trash"></i> حذف
                    </button>
                </div>
            </div>
        `).join('');
        
        this.addUserEvents();
    }
    
    addUserEvents() {
        document.querySelectorAll('.btn-edit-user').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const userId = e.currentTarget.getAttribute('data-id');
                this.editUser(userId);
            });
        });
        
        document.querySelectorAll('.btn-delete-user').forEach(btn => {
            btn.addEventListener('click', (e) => {
                const userId = e.currentTarget.getAttribute('data-id');
                this.deleteUser(userId);
            });
        });
    }
    
    async editUser(userId) {
        // در حالت واقعی باید یک فرم ویرایش نمایش داده شود
        window.location.href = `/support/admin-users.php?action=edit&id=${userId}`;
    }
    
    async deleteUser(userId) {
        if (!confirm('آیا از حذف این کاربر اطمینان دارید؟')) return;
        
        try {
            const response = await fetch(`/support/api/users/${userId}`, {
                method: 'DELETE'
            });
            
            if (response.ok) {
                this.showSuccess('کاربر با موفقیت حذف شد');
                this.loadUsers();
            }
        } catch (error) {
            console.error('خطا در حذف کاربر:', error);
            this.showError('خطا در حذف کاربر');
        }
    }
    
    async searchUsers() {
        const query = this.userSearchInput.value.trim();
        if (query.length < 2) return;
        
        try {
            const response = await fetch(`/support/api/users/search?q=${encodeURIComponent(query)}`);
            const users = await response.json();
            this.renderUsers(users);
        } catch (error) {
            console.error('خطا در جستجوی کاربران:', error);
        }
    }
    
    getStatusText(status) {
        const statusMap = {
            'open': 'باز',
            'pending': 'در حال بررسی',
            'closed': 'بسته شده'
        };
        return statusMap[status] || status;
    }
    
    getPriorityText(priority) {
        const priorityMap = {
            'low': 'کم',
            'medium': 'متوسط',
            'high': 'بالا'
        };
        return priorityMap[priority] || priority;
    }
    
    showLoading(show) {
        if (this.loadingIndicator) {
            this.loadingIndicator.style.display = show ? 'flex' : 'none';
        }
    }
    
    showError(message) {
        this.showNotification(message, 'error');
    }
    
    showSuccess(message) {
        this.showNotification(message, 'success');
    }
    
    showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.innerHTML = `
            <div class="notification-icon">
                ${type === 'error' ? '<i class="fas fa-exclamation-circle"></i>' : 
                 type === 'success' ? '<i class="fas fa-check-circle"></i>' : 
                 '<i class="fas fa-info-circle"></i>'}
            </div>
            <div class="notification-message">${message}</div>
            <button class="notification-close"><i class="fas fa-times"></i></button>
        `;
        
        if (this.notificationArea) {
            this.notificationArea.appendChild(notification);
            
            notification.querySelector('.notification-close').addEventListener('click', () => {
                notification.remove();
            });
            
            setTimeout(() => {
                notification.remove();
            }, 5000);
        }
    }
}

// راه‌اندازی سیستم ادمین
document.addEventListener('DOMContentLoaded', () => {
    const adminSystem = new AdminSupportSystem();
    
    // برای دسترسی از کنسول توسعه‌دهندگان
    window.AdminSupportSystem = adminSystem;
});