class SupportChat {
    constructor() {
        this.userId = document.body.getAttribute('data-user-id');
        this.socket = null;
        this.isTyping = false;
        this.typingTimeout = null;
        this.reconnectAttempts = 0;
        this.maxReconnectAttempts = 5;
        
        this.initElements();
        this.initEvents();
        this.connectWebSocket();
    }
    
    initElements() {
        this.chatMessages = document.getElementById('chatMessages');
        this.messageInput = document.getElementById('messageInput');
        this.sendButton = document.getElementById('sendButton');
        this.typingIndicator = document.getElementById('typingIndicator');
        this.connectionStatus = document.getElementById('connectionStatus');
        this.statusDot = this.connectionStatus.querySelector('.status-dot');
        this.statusText = this.connectionStatus.querySelector('.status-text');
    }
    
    initEvents() {
        this.sendButton.addEventListener('click', () => this.sendMessage());
        this.messageInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter') this.sendMessage();
        });
        
        this.messageInput.addEventListener('input', () => {
            this.handleTyping();
        });
    }
    
    connectWebSocket() {
        // آدرس سرور WebSocket باید پس از راه اندازی سرور تنظیم شود
        this.socket = new WebSocket(`wss://dota2rush.ir/support/ws?user_id=${this.userId}`);
        
        this.socket.onopen = () => {
            this.updateConnectionStatus('connected');
            this.reconnectAttempts = 0;
            this.loadMessageHistory();
        };
        
        this.socket.onmessage = (event) => {
            const data = JSON.parse(event.data);
            this.handleMessage(data);
        };
        
        this.socket.onclose = () => {
            this.updateConnectionStatus('disconnected');
            this.attemptReconnect();
        };
        
        this.socket.onerror = (error) => {
            console.error('WebSocket error:', error);
            this.updateConnectionStatus('error');
        };
    }
    
    handleMessage(data) {
        switch(data.type) {
            case 'message':
                this.appendMessage(data);
                break;
            case 'history':
                this.displayHistory(data.messages);
                break;
            case 'typing':
                this.showTypingIndicator(data.isTyping);
                break;
            case 'status':
                this.updateStatus(data.status);
                break;
        }
    }
    
    appendMessage(message) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${message.sender === 'admin' ? 'admin-message' : 'user-message'}`;
        
        messageDiv.innerHTML = `
            <div class="message-sender">${message.sender === 'admin' ? 'پشتیبان' : 'شما'}</div>
            <div class="message-text">${this.escapeHtml(message.text)}</div>
            <div class="message-time">${this.formatTime(message.timestamp)}</div>
        `;
        
        this.chatMessages.appendChild(messageDiv);
        this.scrollToBottom();
    }
    
    displayHistory(messages) {
        const loadingElement = this.chatMessages.querySelector('.loading-messages');
        if (loadingElement) loadingElement.remove();
        
        this.chatMessages.innerHTML = '';
        messages.forEach(msg => this.appendMessage(msg));
        this.scrollToBottom();
    }
    
    loadMessageHistory() {
        fetch('/support/api/messages?action=history')
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    this.displayHistory(data.messages);
                }
            })
            .catch(error => {
                console.error('Error loading message history:', error);
            });
    }
    
    sendMessage() {
        const text = this.messageInput.value.trim();
        if (!text) return;
        
        const message = {
            type: 'message',
            text: text,
            sender: 'user',
            userId: this.userId,
            timestamp: new Date().toISOString()
        };
        
        if (this.socket.readyState === WebSocket.OPEN) {
            this.socket.send(JSON.stringify(message));
            this.messageInput.value = '';
            this.sendTypingStatus(false);
        } else {
            this.showError('اتصال برقرار نیست. پیام ذخیره شد و پس از اتصال ارسال می‌شود.');
            // در اینجا می‌توانید پیام را در localStorage ذخیره کنید
        }
    }
    
    handleTyping() {
        if (!this.isTyping) {
            this.isTyping = true;
            this.sendTypingStatus(true);
        }
        
        clearTimeout(this.typingTimeout);
        this.typingTimeout = setTimeout(() => {
            this.isTyping = false;
            this.sendTypingStatus(false);
        }, 2000);
    }
    
    sendTypingStatus(isTyping) {
        if (this.socket.readyState === WebSocket.OPEN) {
            this.socket.send(JSON.stringify({
                type: 'typing',
                isTyping: isTyping,
                userId: this.userId
            }));
        }
    }
    
    showTypingIndicator(isTyping) {
        this.typingIndicator.style.display = isTyping ? 'flex' : 'none';
        if (isTyping) this.scrollToBottom();
    }
    
    updateConnectionStatus(status) {
        switch(status) {
            case 'connected':
                this.statusDot.style.backgroundColor = 'var(--success-color)';
                this.statusText.textContent = 'آنلاین';
                break;
            case 'disconnected':
                this.statusDot.style.backgroundColor = 'var(--error-color)';
                this.statusText.textContent = 'آفلاین - در حال تلاش برای اتصال...';
                break;
            case 'error':
                this.statusDot.style.backgroundColor = 'var(--error-color)';
                this.statusText.textContent = 'خطا در اتصال';
                break;
        }
    }
    
    attemptReconnect() {
        if (this.reconnectAttempts < this.maxReconnectAttempts) {
            this.reconnectAttempts++;
            const delay = Math.min(1000 * this.reconnectAttempts, 10000);
            
            setTimeout(() => {
                this.connectWebSocket();
            }, delay);
        } else {
            this.showError('اتصال برقرار نشد. لطفاً صفحه را رفرش کنید.');
        }
    }
    
    scrollToBottom() {
        this.chatMessages.scrollTop = this.chatMessages.scrollHeight;
    }
    
    formatTime(timestamp) {
        return new Date(timestamp).toLocaleTimeString('fa-IR', {
            hour: '2-digit',
            minute: '2-digit'
        });
    }
    
    escapeHtml(unsafe) {
        return unsafe
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }
    
    showError(message) {
        const errorDiv = document.createElement('div');
        errorDiv.className = 'error-message';
        errorDiv.textContent = message;
        
        this.chatMessages.appendChild(errorDiv);
        setTimeout(() => errorDiv.remove(), 5000);
    }
}

// راه اندازی چت پس از بارگذاری کامل صفحه
document.addEventListener('DOMContentLoaded', () => {
    const chat = new SupportChat();
});